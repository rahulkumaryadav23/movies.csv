package com.movies.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movies.dto.MoviesRequestDto;
import com.movies.entity.MoviesCsv;
import com.movies.repository.MoviesRepo;

@Service
public class MoviesImplService implements MoviesService {

	@Autowired
	private MoviesRepo moviesRepo;

	@Override
	public String addMovies(MoviesRequestDto moviesRequestDto) {
		System.out.println("ablddd");
		MoviesCsv user = new MoviesCsv();
		user.setTitleType(moviesRequestDto.getTitleType());
		user.setPrimaryTitle(moviesRequestDto.getPrimaryTitle());
		user.setRuntimeMinutes(moviesRequestDto.getRuntimeMinutes());
		user.setGenres(moviesRequestDto.getGenres());
		moviesRepo.save(user);
		return "your data add successfully";
	}

	@Override
	public List<MoviesCsv> showMovies() {
		// TODO Auto-generated method stub

		return moviesRepo.findAll();
	}
}
