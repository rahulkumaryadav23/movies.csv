
package com.movies.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MoviesRequestDto {

	private String titleType;
	private String primaryTitle;
	private String runtimeMinutes;
	private String genres;
}
