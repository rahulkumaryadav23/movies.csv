package com.movies.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movies.entity.MoviesCsv;

public interface MoviesRepo extends JpaRepository<MoviesCsv, Long> {

}
