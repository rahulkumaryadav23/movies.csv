package com.movies.service;

import java.util.List;

import com.movies.dto.MoviesRequestDto;
import com.movies.entity.MoviesCsv;

public interface MoviesService {

	String addMovies(MoviesRequestDto moviesRequestDto);

	List<MoviesCsv> showMovies();

}
