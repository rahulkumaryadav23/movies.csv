package com.movies.service;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movies.entity.MoviesCsv;
import com.movies.entity.RatingsCvs;
import com.movies.repository.MoviesRepo;
import com.opencsv.CSVWriter;

@Service
public class CsvServiceImple implements CsvService {

	@Override
	public String generateCsvFile(List<MoviesCsv> moviesCsvs)  throws IOException {
//		"C:\Users\Msi-pc\Desktop\csv"
	     // Create a temporary file to store the CSV data
        String filePath = "C:\\Users\\Msi-pc\\Desktop\\csv\\" +UUID.randomUUID()+ ".csv";
        FileWriter fileWriter = new FileWriter(filePath);

        // Create the CSV writer using OpenCSV
        CSVWriter csvWriter = new CSVWriter(fileWriter);

        // Write the CSV header
        String[] header = {"tconst", "title Type", "Primary Title", "runtime Minutes", "genres"};
        csvWriter.writeNext(header);

        // Write the CSV data rows
        String[] row1 = (String[]) moviesCsvs.toArray();
        csvWriter.writeNext(row1);

        // Close the CSV writer and file writer
        csvWriter.close();
        fileWriter.close();
        return filePath;
	}

	@Override
	public String generateRatingCsvFile(List<RatingsCvs> ratingsCvs) throws IOException {
		 String filePath = "C:\\Users\\Msi-pc\\Desktop\\csv\\" +UUID.randomUUID()+ ".csv";
	        FileWriter fileWriter = new FileWriter(filePath);

	        // Create the CSV writer using OpenCSV
	        CSVWriter csvWriter = new CSVWriter(fileWriter);

	        // Write the CSV header
	        String[] header = {"tconst", "average Rating", "num Votes"};
	        csvWriter.writeNext(header);

	        // Write the CSV data rows
	        String[] row1 = (String[]) ratingsCvs.toArray();
	        csvWriter.writeNext(row1);

	        // Close the CSV writer and file writer
	        csvWriter.close();
	        fileWriter.close();
	        return filePath;
	}
	
	

}
