package com.movies.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.movies.dto.MoviesRequestDto;
import com.movies.entity.MoviesCsv;
import com.movies.service.CsvService;
import com.movies.service.MoviesService;

@RestController
@RequestMapping("/api")
public class MovieController {

	@Autowired
	private MoviesService moviesService;
	
	@Autowired
	private CsvService csvService;

	@PostMapping("/addMoves")
	public String addMovies(@RequestBody MoviesRequestDto moviesRequestDto) {
		return moviesService.addMovies(moviesRequestDto);

	}

	@GetMapping("showAllMovies")
	public List<MoviesCsv> showall() {
		return moviesService.showMovies();
	}
	
	@PostMapping("/movie/csv")
	public String exportCsv() throws IOException {
		return csvService.generateCsvFile(moviesService.showMovies());
	}
	
	@PostMapping("/rating/csv")
	public String exportRatingCsv() throws IOException {
		return csvService.generateRatingCsvFile(moviesService.showMovies());
	}
	

}
