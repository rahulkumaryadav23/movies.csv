package com.movies.service;

import java.io.IOException;
import java.util.List;
import com.movies.entity.MoviesCsv;
import com.movies.entity.RatingsCvs;

public interface CsvService {
	
	 public String generateCsvFile(List<MoviesCsv> moviesCsvs)  throws IOException;
	 
	 public String generateRatingCsvFile(List<RatingsCvs> ratingsCvs)  throws IOException;

}
